package com.sanvalero.telovendo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelovendoApplicationTests {

	@Test
	void contextLoads() {
	}

}
