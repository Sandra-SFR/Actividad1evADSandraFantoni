package com.sanvalero.telovendo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TelovendoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TelovendoApplication.class, args);
	}

}
